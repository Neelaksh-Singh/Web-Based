
<?php
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\Exception;
		require './PHPMailer/src/Exception.php';
			require './PHPMailer/src/PHPMailer.php';
			require './PHPMailer/src/SMTP.php';

	if(isset($_POST['button'])){
		echo("working");
	// Load Composer's autoloader
		
	function sendemailtome($email,$name,$phone,$address,$message,$city,$zip_Code,$state ,$company,$msg ,$file){
		//Recipients
						
			// Load Composer's autoloader
			

			// Instantiation and passing `true` enables exceptions
			$mail = new PHPMailer(true);
		
			try {
			//Server settings
			$mail->SMTPDebug = 2;                                       // Enable verbose debug output
			$mail->isSMTP();                                            // Set mailer to use SMTP
			$mail->Host       = "smtp.gmail.com"; 					 // Specify main and backup SMTP servers
			$mail->SMTPAuth   = true;                                   // Enable SMTP authentication
			$mail->Username   = 'tempmail25019@gmail.com';                     // SMTP username
			$mail->Password   = 'wfktkibvlejsvisy';                               // SMTP password
			$mail->SMTPSecure = 'tls';                                  // Enable TLS encryption, `ssl` also accepted
			$mail->Port       = 587;                                    // TCP port to connect to

			
			

			// Instantiation and passing `true` enables exceptions
			
			$mail->setFrom('tempmail25019@gmail.com', 'CLIENT');
			$mail->addAddress('tempmail25019@gmail.com', 'UNFOLDCRAFT');     // Add a recipient

			// Content
			$mail->isHTML(true);     
			if($_FILES['attachment']['name']){
			$mail->addAttachment($file);                               // Set email format to HTML
			}
			$mail->Subject = 'Here is the '.$name;
			$mail->Body    = '<b>FULL NAME:</b>'.$name.'<br> <b>Email:</b>'.$email.'<br> <b>Phone:</b>'.$phone.'<br><b>Address:</b>'.$address.'<br><b>City:</b>'.$city.'<br><b>Zip Code:</b>'.$zip_Code.'<br><b>State:</b>'.$state.'<br><b>Company:</b>'.$company.'<br><b style="color:red;">Message:</b>'.$msg.' ';
			$mail->AltBody = 'This is the body  plain text for non-HTML mail clients';
			return $mail->send();
			
			
			}
			
			catch(Exception $e) {
			echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
			}
	
		 
		} 
	function sendmailtoclient($email,$name){
		
		//Recipients
						
			// Load Composer's autoloader
			

			// Instantiation and passing `true` enables exceptions
			$mail = new PHPMailer(true);
		
			try {
			//Server settings
			$mail->SMTPDebug = 2;                                       // Enable verbose debug output
			$mail->isSMTP();                                            // Set mailer to use SMTP
			$mail->Host       = "smtp.gmail.com"; 					 // Specify main and backup SMTP servers
			$mail->SMTPAuth   = true;                                   // Enable SMTP authentication
			$mail->Username   = 'tempmail25019@gmail.com';                     // SMTP username
			$mail->Password   = 'wfktkibvlejsvisy';                               // SMTP password
			$mail->SMTPSecure = 'tls';                                  // Enable TLS encryption, `ssl` also accepted
			$mail->Port       = 587;                                    // TCP port to connect to

			
			

			// Content
			$mail->isHTML(true);     
			
		             
			
			
			
			
			
			$mail->setFrom('tempmail25019@gmail.com', 'UNFOLDCRAFT');
			$mail->addAddress($email,$name);   
			$mail->isHTML(true);                                  // Set email format to HTML
			$mail->Subject = 'Hello '.$name;
			$mail->Body    = 'We appreciate you contacting us. One of our colleagues will get back to you shortly. We’re thrilled to hear from you. Our inbox can’t wait to get your messages, so talk to us any time you like. Have a great day! 
								<br><a href="http://unfoldcraft.com/">www.unfoldcraft.com</a>';
			$mail->AltBody = 'This is the body  plain text for non-HTML mail clients';
			$mail->send();
			}
			
			catch(Exception $e) {
			echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
			}
	
		 
	}
		
		$name = $_POST['full-name'];
		$email = $_POST['email'];
		$phone = $_POST['phone'];
		$address = $_POST['address'];
		$city = $_POST['city'];
		$zip_Code = $_POST['zip_Code'];
		$state = $_POST['state'];
		$company = $_POST['company'];
		$message = $_POST['message'];
		
		if($_FILES['attachment']['name']){
		$file_tmp_loc = $_FILES['attachment']['tmp_name']; 
		$file = "upload/". basename($_FILES['attachment']['name']);
		}
	
		if(isset($_POST['button'])){
			if(sendemailtome($email,$name,$phone,$address,$message,$city,$zip_Code,$state ,$company,$message ,$file)){
				$msg ='Email sent';
				sendmailtoclient($email,$name);
			}
			else{
				$msg = 'email Failed';
			}
			echo($msg);
		}
	
				
		// Import PHPMailer classes into the global namespace
		// These must be at the top of your script, not inside a function


		

	


			

		}
		else{
			echo("not working");
		}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="UnfoldCraft : Digital Design and Develpoment Services">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title -->
    <title>UnfoldCraft : we screen your thoughts</title>
	
	
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Favicon -->
    <link rel="icon" href="./img/core-img/favicon.ico">

    <!-- Core Stylesheet -->
    <link rel="stylesheet" href="style.css">
	
</head>

<body>

<div class="jumbotron text-xs-center">
  <h1 class="display-3">Thank You!</h1>
  <p class="lead"><strong>Please check your email</strong> for further instructions.</p>
  <hr>
  <p>
    Having trouble? <a href="tel:+919358271377">Contact us</a>
  </p>
  <p class="lead">
    <a class="btn btn-primary btn-sm" href="index.php" role="button">Continue to homepage</a>
  
  </p>
</div>
</body>
</html>
