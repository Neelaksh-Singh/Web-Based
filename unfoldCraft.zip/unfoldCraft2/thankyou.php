<?php
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\Exception;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="UnfoldCraft : Digital Design and Develpoment Services">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title -->
    <title>UnfoldCraft : we screen your thoughts</title>
	
	
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Favicon -->
    <link rel="icon" href="./img/core-img/favicon.ico">

    <!-- Core Stylesheet -->
    <link rel="stylesheet" href="style.css">
	
</head>

<body>

<div class="jumbotron text-xs-center">
  <h1 class="display-3">Thank You!</h1>
  <p class="lead"><strong>Please check your email</strong> for further instructions.</p>
  <hr>
  <p>
    Having trouble? <a href="tel:+919358271377">Contact us</a>
  </p>
  <p class="lead">
    <a class="btn btn-primary btn-sm" href="index.php" role="button">Continue to homepage</a>
  
  </p>
</div>
</body>
</html>


<?php
	if(isset($_POST['button'])){
		$name = $_POST['full-name'];
		
		$email = $_POST['email'];
		$phone = $_POST['phone'];
		$subject = $_POST['subject'];
		
		
		$message = $_POST['message'];
		
	

// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function


// Load Composer's autoloader
require './PHPMailer/src/Exception.php';
require './PHPMailer/src/PHPMailer.php';
require './PHPMailer/src/SMTP.php';


// Instantiation and passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = 0;                                       // Enable verbose debug output
    $mail->isSMTP();                                            // Set mailer to use SMTP
    $mail->Host       = "secure1.natsav.info"; 					 // Specify main and backup SMTP servers
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = 'project@unfoldcraft.com';                     // SMTP username
    $mail->Password   = 'Nnfoldcraft94314277';                               // SMTP password
    $mail->SMTPSecure = 'tls';                                  // Enable TLS encryption, `ssl` also accepted
    $mail->Port       = 587;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('project@unfoldcraft.com', 'CLIENT');
    $mail->addAddress('project@unfoldcraft.com', 'UNFOLDCRAFT');     // Add a recipient

	 

    // Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Here is the '.$name;
    $mail->Body    = '<b>FULL NAME:</b>'.$name.'<br> <b>Email:</b>'.$email.'<br> <b>Phone:</b>'.$phone.'<br><b>Subject:</b>'.$subject.'<br><b style="color:red;">Message:</b>'.$message.' ';
    $mail->AltBody = 'This is the body  plain text for non-HTML mail clients';
    $mail->send();
    
    
    
	// Remove previous recipients
	$mail->ClearAllRecipients();
    $mail->setFrom('project@unfoldcraft.com', 'UNFOLDCRAFT');
    $mail->addAddress($email,$name);   
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Hello '.$name;
    $mail->Body    = 'We appreciate you contacting us. One of our colleagues will get back to you shortly. We’re thrilled to hear from you. Our inbox can’t wait to get your messages, so talk to us any time you like. Have a great day! 
						<br><a href="http://unfoldcraft.com/">www.unfoldcraft.com</a>';
    $mail->AltBody = 'This is the body  plain text ';
    $mail->send();
    
   
    
} 
catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
}


?>

