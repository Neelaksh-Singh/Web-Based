<?php
	
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\Exception;
	require './PHPMailer/src/Exception.php';
	require './PHPMailer/src/PHPMailer.php';
	require './PHPMailer/src/SMTP.php';

?>






<?php
	
	$notify="";
	
	if(isset($_POST['button'])){
		
	// Load Composer's autoloader
		
	function sendemailtome($email,$name,$phone,$address,$message,$city,$zip_Code,$state ,$company,$msg ,$file){
		//Recipients
						
			// Load Composer's autoloader
			

			// Instantiation and passing `true` enables exceptions
			$mail = new PHPMailer(true);
		
			try {
			//Server settings
			$mail->SMTPDebug = 0;                                       // Enable verbose debug output
			$mail->isSMTP();                                            // Set mailer to use SMTP
			$mail->Host       = "secure1.natsav.info"; 					 // Specify main and backup SMTP servers
			$mail->SMTPAuth   = true;                                   // Enable SMTP authentication
			$mail->Username   = 'project@unfoldcraft.com';                     // SMTP username
			$mail->Password   = 'Nnfoldcraft94314277';                               // SMTP password
			$mail->SMTPSecure = 'tls';                                  // Enable TLS encryption, `ssl` also accepted
			$mail->Port       = 587;                                    // TCP port to connect to

			
			

			// Instantiation and passing `true` enables exceptions
			
			$mail->setFrom('project@unfoldcraft.com', 'CLIENT');
			$mail->addAddress('project@unfoldcraft.com', 'UNFOLDCRAFT');     // Add a recipient

			// Content
			$mail->isHTML(true);     
			if($_FILES['attachment']['name']){
			$mail->addAttachment($file);                               // Set email format to HTML
			}
			$mail->Subject = 'Here is the '.$name;
			$mail->Body    = '<b>FULL NAME:</b>'.$name.'<br> <b>Email:</b>'.$email.'<br> <b>Phone:</b>'.$phone.'<br><b>Address:</b>'.$address.'<br><b>City:</b>'.$city.'<br><b>Zip Code:</b>'.$zip_Code.'<br><b>State:</b>'.$state.'<br><b>Company:</b>'.$company.'<br><b style="color:red;">Message:</b>'.$msg.' ';
			$mail->AltBody = 'This is the body  plain text for non-HTML mail clients';
			return $mail->send();
			
			
			}
			
			catch(Exception $e) {
			echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
			}
	
		 
		} 
	function sendmailtoclient($email,$name){
		
		//Recipients
						
			// Load Composer's autoloader
			

			// Instantiation and passing `true` enables exceptions
			$mail = new PHPMailer(true);
		
			try {
			//Server settings
			$mail->SMTPDebug = 0;                                       // Enable verbose debug output
			$mail->isSMTP();                                            // Set mailer to use SMTP
			$mail->Host       = "secure1.natsav.info"; 					 // Specify main and backup SMTP servers
			$mail->SMTPAuth   = true;                                   // Enable SMTP authentication
			$mail->Username   = 'project@unfoldcraft.com';                     // SMTP username
			$mail->Password   = 'Nnfoldcraft94314277';                               // SMTP password
			$mail->SMTPSecure = 'tls';                                  // Enable TLS encryption, `ssl` also accepted
			$mail->Port       = 587;                                    // TCP port to connect to

			
			

			// Content
			$mail->isHTML(true);     
			
		             
			
			
			
			
			
			$mail->setFrom('project@unfoldcraft.com', 'UNFOLDCRAFT');
			$mail->addAddress($email,$name);   
			$mail->isHTML(true);                                  // Set email format to HTML
			$mail->Subject = 'Hello '.$name;
			$mail->Body    = 'We appreciate you contacting us. One of our colleagues will get back to you shortly. We’re thrilled to hear from you. Our inbox can’t wait to get your messages, so talk to us any time you like. Have a great day! 
								<br><a href="http://unfoldcraft.com/">www.unfoldcraft.com</a>';
			$mail->AltBody = 'This is the body  plain text for non-HTML mail clients';
			$mail->send();
			}
			
			catch(Exception $e) {
			echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
			}
	
		 
	}
		
		$name = $_POST['full-name'];
		$email = $_POST['email'];
		$phone = $_POST['phone'];
		$address = $_POST['address'];
		$city = $_POST['city'];
		$zip_Code = $_POST['zip_Code'];
		$state = $_POST['state'];
		$company = $_POST['company'];
		$message = $_POST['message'];
		$file="";
		if($_FILES['attachment']['name']){
		$file_tmp_loc = $_FILES['attachment']['tmp_name']; 
		$file = "upload/". basename($_FILES['attachment']['name']);
		}
	
		if(isset($_POST['button'])){
			if(sendemailtome($email,$name,$phone,$address,$message,$city,$zip_Code,$state ,$company,$message ,$file)){
				$notify ='Email sent';
				
				sendmailtoclient($email,$name);
			}
			else{
				
				$notify = 'email Failed';
			}
			
		}
	
				
		// Import PHPMailer classes into the global namespace
		// These must be at the top of your script, not inside a function

		}
		
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="UnfoldCraft : Digital Design and Develpoment Services">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title -->
    <title>UnfoldCraft : we screen your thoughts</title>

    <!-- Favicon -->
    <link rel="icon" href="./img/core-img/favicon.ico">

    <!-- Core Stylesheet -->
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div class="wrapper">
            <div class="cssload-loader"></div>
        </div>
    </div>

   

   <?php
			include('./header.php');
   ?>
    <!-- ***** Breadcrumb Area Start ***** -->
    <div class="breadcrumb-area">
        <div class="container h-100">
            <div class="row h-100 align-items-end">
                <div class="col-12">
                    <div class="breadcumb--con">
                        <h2 class="title">Request Your Service</h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home"></i> Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Request Your Service</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>

        <!-- Background Curve -->
        <div class="breadcrumb-bg-curve">
            <img src="./img/core-img/curve-5.png" alt="">
        </div>
    </div>
    <!-- ***** Breadcrumb Area End ***** -->

    <!-- ***** Contact Area Start ***** -->
    <section class="ufc-contact-area section-padding-80 request_service_form">
        <div class="container">
            <div class="row justify-content-between">
                <!-- Contact Form -->
                <div class="col-12 col-lg-8">
                    <div class="ufc-contact-form mb-80">
                       
                       
                        <form action="<?php $_SERVER['PHP_SELF'];?>" method="POST" enctype="multipart/form-data">
                            <div class="row">
								
								
								
								
								
								 <div class="col-lg-6">
                                   <h4>
                                   
									<?php
										if($notify){
											echo('
																						
																						
										<div class="jumbotron text-xs-center">
										  <h1 class="display-3">Thank You!</h1>
										  <p class="lead"><strong>Please check your email</strong> for further instructions.</p>
										  <hr>
										  <p>
											Having trouble? <a href="tel:+919358271377">Contact us</a>
										  </p>
										  <p class="lead">
											<a class="btn btn-primary btn-sm" href="index.php" role="button">Continue to homepage</a>
										  
										  </p>
										</div>
												
												
											');
										}
										
									?>
											
                                   </h4>
                                </div>
								
								
								
								
								   <div class="col-lg-6">
										
                                </div>
								
                                <div class="col-lg-6">
                                   <h4>CLIENT INFORMATION</h4>
                                </div>
                                <div class="col-lg-6">
										
                                </div>
                                   
                               <div class="col-lg-6">
										<p></p>
                                </div>
                                <div class="col-lg-6">
										<p></p>
                                </div>
                                
                                
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control mb-30" name="full-name" placeholder="Name" required>
                                    </div>
                                </div>
                                 <div class="col-lg-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control mb-30" name="phone" placeholder="Phone" required>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input type="email" class="form-control mb-30" name="email" placeholder="Email" required>
                                    </div>
                                </div>
                               
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control mb-30" name="address" placeholder="Address" required>
                                    </div>
                                </div>
                                 <div class="col-lg-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control mb-30" name="state" placeholder="State" required>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control mb-30" name="city" placeholder="City" required>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control mb-30" name="zip_Code" placeholder="Zip Code" required>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group btn " style="margin-top:7px;">
										<span>Attach file</span>
                                        <input type="file"  name="attachment">
                                    </div>
                                </div>
                                
                               
                                
                                
                                
                               
                                <div class="col-lg-6">
                                   <h4>PROJECT INFORMATION</h4>
                                </div>
                                 <div class="col-lg-6">
                                   
                                   
                                </div>
                               
                               <div class="col-lg-6">
										<p></p>
                                </div>
                                <div class="col-lg-6">
										<p></p>
                                </div>
                                
                              
                                <div class="col-lg-6" >
                                    <div class="form-group" >
										
                                        <input type="radio"  name="company" value="indivisual" required><span style="margin-right: 55px;">indivisual</span>
                                        <input type="radio"  name="company" value="Commercial" required>Commercial
                                       
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                      
                                        <input type="radio"  name="company"  value="government" required><span style="margin-right: 55px;">Government</span>
                                        <input type="radio"  name="company" value="non profit" required>Non Profit
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                        <textarea class="form-control mb-30" name="message" rows="8" cols="80" placeholder="Project Description" ></textarea>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <button class="btn ufc-btn btn-3 mt-15 " name="button" >REQUEST</button>
                                </div>
                                
                            </div>
                        </form>
                        
              
                        
                        
                    </div>
                </div>



				
                  <!-- Single Contact Card -->
                <div class="col-12 col-lg-3">
                    <div class="contact-sidebar-area mb-80">
                        <!-- Single Sidebar Area -->
                        <div class="single-contact-card mb-50">
                            <h4>Contact Us</h4>
                            <h3>+91-9358271377</h3>
                            <h6>info@unfoldcraft.com</h6>
                            <h6>Mon - Sat: 24hrs.  <br>Closed on Sunday</h6>
                        </div>

                        <!-- Single Sidebar Area -->
                        <div class="single-contact-card mb-50">
                            <h4>Jharkhand (Head Office)</h4>
                            <h3>+91-9358271377</h3>
                            <h6>Po.Ratu,Ps.Ratu , Vill.Jhakaratand,Ranchi<br>info@unfoldcraft.com</h6>
                        </div>

                        <!-- Single Sidebar Area -->
                        <div class="single-contact-card mb-50">
                            <h4>Rajasthan (Branch Office)</h4>
                            <h3>+91-9358271377</h3>
                            <h6>Malviya Nagar Industrial Area, Malviya Nagar  <br>info@unfoldcraft.com</h6>
                        </div>
                    </div>
                </div>
            </div>
                
              </div>
            </div>

    </section>
    <!-- ***** Contact Area End ***** -->


























































	<!-- footer------------------------------------------------------>
	
		<?php 
			include('footer.php');
		?>
	
	<!-- footer------------------------------------------------------>



    <!-- ******* All JS Files ******* -->
    <!-- jQuery js -->
    <script src="js/jquery.min.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- All js -->
    <script src="js/ufc.bundle.js"></script>
    <!-- Active js -->
    <script src="js/default-assets/active.js"></script>

</body>

</html>


