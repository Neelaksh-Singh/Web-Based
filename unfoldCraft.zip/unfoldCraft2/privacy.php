<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="UnfoldCraft : Digital Design and Develpoment Services">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title -->
    <title>UnfoldCraft : we screen your thoughts</title>

    <!-- Favicon -->
    <link rel="icon" href="./img/core-img/favicon.ico">

    <!-- Core Stylesheet -->
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div class="wrapper">
            <div class="cssload-loader"></div>
        </div>
    </div>

    <!-- ***** Top Search Area Start ***** -->
    <div class="top-search-area">
        <!-- Search Modal -->
        <div class="modal fade" id="searchModal" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <!-- Close Button -->
                        <button type="button" class="btn close-btn" data-dismiss="modal"><i class="fa fa-times"></i></button>
                        <!-- Form -->
                        <form action="index.html" method="post">
                            <input type="search" name="top-search-bar" class="form-control" placeholder="Search and hit enter...">
                            <button type="submit">Search</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ***** Top Search Area End ***** -->

    <!-- ***** Header Area Start ***** -->
		<?php
			include('header.php');
		?>
    <!-- ***** Header Area End ***** -->

    <!-- ***** Breadcrumb Area Start ***** -->
    <div class="breadcrumb-area">
        <div class="container h-100">
            <div class="row h-100 align-items-end">
                <div class="col-12">
                    <div class="breadcumb--con">
                        <h2 class="title">PRIVACY & POLICY</h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home"></i> Home</a></li>
                             
                                 <li class="breadcrumb-item active" aria-current="page">PRIVACY & POLICY</li>
                               
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>

        <!-- Background Curve -->
        <div class="breadcrumb-bg-curve">
            <img src="./img/core-img/curve-5.png" alt="">
        </div>
    </div>
    <!-- ***** Breadcrumb Area End ***** -->

    <!-- ***** Portfolio Single Area Start ***** -->
    <section class="ufc-portfolio-single-area section-padding-80">
        <div class="container">
            <div class="row justify-content-between align-items-end">
                <div class="col-12">
					
                    <div class="portfolio-details-text">
                        <h2>SECTION 1 – WHAT DO WE DO WITH YOUR INFORMATION?</h2>
                       
                        <p>
							
							
    When you purchase something from us or avail any kind of service, as part of the buying and selling process, we collect the personal information you give us such as your name, address and email address etc.
    When you browse our service, website, product, we also automatically receive your computer’s internet protocol (IP) address in order to provide us with information that helps us learn about your browser and operating system.
    Email marketing (if applicable): With your permission, we may send you emails about our store, services, offers, new products and other updates.

						</p>
                    </div>
                    <br>
                    <br>
                    <div class="portfolio-details-text">
                        <h2>SECTION 2 – CONSENT</h2>
                       
                        <p>
    How do you get our consent?
    When you provide us with personal information to complete a transaction, verify your credit/debit card, place an order, arrange for a delivery or exchange a purchase, we imply that you consent to our collecting it and using it for that specific reason only.
    we ask for your personal information for a secondary reason, like marketing, we will either ask you directly for your expressed consent, or provide you with an opportunity to say no.
    How do I withdraw my consent?
    If after you opt-in, you change your mind, you may withdraw your consent for us to contact you, for the continued collection, use or disclosure of your information, at anytime, by contacting us at contact@unfoldcraft.com or mailing at unfoldcraft@gmail.com

						</p>
</div><br>
                    <br>
                    <div class="portfolio-details-text">
                        <h2>SECTION 3 – DISCLOSURE</h2>
                       
                        <p>
    We may disclose your personal information if we are required by law to do so or if you violate our Terms of Service.

</p>
  </div><br>
                    <br>
                    <div class="portfolio-details-text">
                        <h2>SECTION 4 – PAYMENT</h2>
                       
                        <p>
    We only accept payment by cheque, Indian rupee cash (only in a small amount), payment thorough paytm and Google pay.
</p></div><br>
                    <br>
                    <div class="portfolio-details-text">
                        <h2>SECTION 5 – THIRD-PARTY SERVICES</h2>
                       
                        <p>
							
							
    In general, the third-party providers used by us will only collect, use and disclose your information to the extent necessary to allow them to perform the services they provide to us.
    However, certain third-party service providers, such as payment gateways and other payment transaction processors, have their own privacy policies in respect to the information we are required to provide to them for your purchase-related transactions.
    For these providers, we recommend that you read their privacy policies so you can understand the manner in which your personal information will be handled by these providers.
    In particular, remember that certain providers may be located in or have facilities that are located a different jurisdiction than either you or us. So if you elect to proceed with a transaction that involves the services of a third- party service provider, then your information may become subject to the laws of the jurisdiction(s) in which that service provider or its facilities are located.
    Once you leave our store’s website or are redirected to a third-party website or application, you are no longer governed by this Privacy Policy or our website’s Terms of Service.
    Links
    When you click on links on our store and website, they may direct you away from our site. We are not responsible for the privacy practices of other sites and encourage you to read their privacy statements.

							</p> </div><br>
                    <br>
                    <div class="portfolio-details-text">
                        <h2>SECTION 6 – SECURITY</h2>
                       
                        <p>We reserve the right to refuse any order you place with us. We may, in our sole discretion, limit or cancel quantities purchased per person, per household or per order. These restrictions may include orders placed by or under the same customer account, the same credit card, and/or orders that use the same billing and/or shipping address. In the event that we make a change to or cancel an order, we may attempt to notify you by contacting the e-mail and/or billing address/phone number provided at the time the order was made. We reserve the right to limit or prohibit orders that, in our sole judgment, appear to be placed by dealers, resellers or distributors.

You agree to provide current, complete and accurate purchase and account information for all purchases made at our store. You agree to promptly update your account and other information, including your email address and credit card numbers and expiration dates, so that we can complete your transactions and contact you as needed.</p></div>
                    <br>
                    <br><div class="portfolio-details-text">
                        <h2>SECTION 6 – OPTIONAL TOOLS</h2>
                       
                        <p>To protect your personal information, we take reasonable precautions and follow industry best practices to make sure it is not inappropriately lost, misused, accessed, disclosed, altered or destroyed.
							</p> </div><br>
                    <br>
                    <div class="portfolio-details-text">
                        <h2>SECTION 7 – COOKIES</h2>
                       
                        <p>

    We use cookies to maintain session of your user. It is not used to personally identify you on other websites.

                        </p></div><br>
                    <br>
                    <div class="portfolio-details-text">
                        <h2>SECTION 8 – AGE OF CONSENT</h2>
                       
                        <p>
							By using this site, you represent that you are at least the age of majority in your state or province of residence, or that you are the age of majority in your state or province of residence and you have given us your consent to allow any of your minor dependents to use this site.
                        </p></div><br>
                    <br>
                    <div class="portfolio-details-text">
                        <h2>SECTION 9 – CHANGES TO THIS PRIVACY POLICY</h2>
                       
                        <p>
							
    We reserve the right to modify this privacy policy at any time, so please review it frequently. Changes and clarifications will take effect immediately upon their posting on the website. If we make material changes to this policy, we will notify you here that it has been updated, so that you are aware of what information we collect, how we use it, and under what circumstances, if any, we use and/or disclose it.
    If our store is acquired or merged with another company, your information may be transferred to the new owners so that we may continue to sell products to you.


							</p>  </div><br>
                    <br>
                  
                </div>
               
            </div>

           
        </div>
    </section>
    <!-- ***** Portfolio Single Area End ***** -->



    <!-- ***** Footer Area Start ***** -->
		
    <!-- ***** Footer Area End ***** -->

    <!-- ******* All JS Files ******* -->
    <!-- jQuery js -->
    <script src="js/jquery.min.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- All js -->
    <script src="js/ufc.bundle.js"></script>
    <!-- Active js -->
    <script src="js/default-assets/active.js"></script>

</body>

</html>
